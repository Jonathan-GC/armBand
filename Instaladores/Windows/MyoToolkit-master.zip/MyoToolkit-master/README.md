# Myo Toolkit
A list of software for using [Thalmic's Myo armband](https://www.myo.com).

## Description

Looking for anything online can be a pain, especially when it comes to open and free software. This is the reason that pushed me to share with you a list all code useful applications for using the [Myo armband](https://www.myo.com).

This list will be continuously improved by me, but please feel free to fork the repository to fork and improve it. I guess that as it will probably help you, it can be a massively helpful for whomever is desperately looking for the right bit of code for making the Myo armband working as expected.

Happy coding!
